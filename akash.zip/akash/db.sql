CREATE DATABASE atmdb;
USE atmdb;

CREATE TABLE accounts (
    acc_no INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    pin INT,
    balance DOUBLE
);
