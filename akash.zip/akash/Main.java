import java.sql.*;
import java.util.Scanner;

public class Main {

    static final String URL = "jdbc:mysql://localhost:3306/atmdb?useSSL=false&serverTimezone=UTC";
    static final String USER = "root";
    static final String PASS = "anvi@27";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(URL, USER, PASS);

            while (true) {
                System.out.println("\n1. Create Account");
                System.out.println("2. Check Balance");
                System.out.println("3. Deposit");
                System.out.println("4. Withdraw");
                System.out.println("5. Exit");
                System.out.print("Choose: ");
                int ch = sc.nextInt();

                if (ch == 1) {
                    sc.nextLine();
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Set PIN: ");
                    int pin = sc.nextInt();
                    System.out.print("Initial Deposit: ");
                    double bal = sc.nextDouble();

                    PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO accounts(name, pin, balance) VALUES (?, ?, ?)");
                    ps.setString(1, name);
                    ps.setInt(2, pin);
                    ps.setDouble(3, bal);
                    ps.executeUpdate();
                    System.out.println("Account Created!");

                } else if (ch == 2) {
                    System.out.print("Enter Account No: ");
                    int acc = sc.nextInt();
                    System.out.print("Enter PIN: ");
                    int pin = sc.nextInt();

                    PreparedStatement ps = con.prepareStatement(
                        "SELECT balance FROM accounts WHERE acc_no=? AND pin=?");
                    ps.setInt(1, acc);
                    ps.setInt(2, pin);
                    ResultSet rs = ps.executeQuery();

                    if (rs.next())
                        System.out.println("Balance = ₹" + rs.getDouble("balance"));
                    else
                        System.out.println("Wrong details!");

                } else if (ch == 3) {
                    System.out.print("Account No: ");
                    int acc = sc.nextInt();
                    System.out.print("Amount: ");
                    double amt = sc.nextDouble();

                    PreparedStatement ps = con.prepareStatement(
                        "UPDATE accounts SET balance=balance+? WHERE acc_no=?");
                    ps.setDouble(1, amt);
                    ps.setInt(2, acc);
                    ps.executeUpdate();
                    System.out.println("Deposit Successful!");

                } else if (ch == 4) {
                    System.out.print("Account No: ");
                    int acc = sc.nextInt();
                    System.out.print("PIN: ");
                    int pin = sc.nextInt();
                    System.out.print("Amount: ");
                    double amt = sc.nextDouble();

                    PreparedStatement check = con.prepareStatement(
                        "SELECT balance FROM accounts WHERE acc_no=? AND pin=?");
                    check.setInt(1, acc);
                    check.setInt(2, pin);
                    ResultSet rs = check.executeQuery();

                    if (rs.next()) {
                        double bal = rs.getDouble("balance");
                        if (bal >= amt) {
                            PreparedStatement ps = con.prepareStatement(
                                "UPDATE accounts SET balance=balance-? WHERE acc_no=?");
                            ps.setDouble(1, amt);
                            ps.setInt(2, acc);
                            ps.executeUpdate();
                            System.out.println("Withdraw Successful!");
                        } else {
                            System.out.println("Insufficient balance!");
                        }
                    } else {
                        System.out.println("Wrong details!");
                    }

                } else {
                    break;
                }
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
